package com.example.chat_psicotinder.model

data class NotificationData(
    var title:String,
    var message:String
)