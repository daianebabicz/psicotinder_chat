package com.example.chat_psicotinder.model

data class PushNotification(
    var data:NotificationData,
    var to:String
)